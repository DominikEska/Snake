package snake;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

import snake.Snake.STATUS;

/**
 * Klasa odpowiedzialna za wy�wietlanie gry
 * @author Wojciech Kwiatkowski
 */


@SuppressWarnings({ "serial" })
public class RysujObraz extends JPanel {
	/**
	 * Funkcja rysuj�ca elementy gry
	 */
	@SuppressWarnings("static-access")
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		
		Snake snake = Snake.snake;

		
		if(snake.status==STATUS.GRA){
			
		
			
			int clr = Ustawienia.ustawienia.color_tla;
			switch(clr){
			case 1: g.setColor(Color.BLUE);
			break;
			case 2: g.setColor(Color.BLACK);
			break;
			case 3: g.setColor(Color.LIGHT_GRAY);
			break;
			case 4: g.setColor(new Color(0, 100, 0));
			break;
			}
				
			
			snake.WIDTH = snake.jframe.getWidth();
			snake.HEIGHT=snake.jframe.getHeight();
			g.fillRect(0, 0, snake.WIDTH, snake.HEIGHT);
			
			
			int clrw = Ustawienia.ustawienia.color_weza;
			
			switch(clrw){
			case 1: g.setColor(Color.CYAN);
			break;
			case 2: g.setColor(Color.RED);
			break;
			case 3: g.setColor(Color.PINK);
			break;
			case 4: g.setColor(Color.GREEN);
			break;
			}
		
		for ( Point point : snake.polozenieSnake){
			g.fillRect(point.x * snake.SKALA, point.y * snake.SKALA, snake.SKALA, snake.SKALA);
		}
		g.setColor(Color.GREEN);
		if(snake.kierunek == 1)
			g.fillArc(snake.head.x * snake.SKALA , snake.head.y * snake.SKALA, snake.SKALA, snake.SKALA, 180, 180);
		if(snake.kierunek == 0)
			g.fillArc(snake.head.x * snake.SKALA , snake.head.y * snake.SKALA, snake.SKALA, snake.SKALA, 360, 180);
		if(snake.kierunek == 2)
			g.fillArc(snake.head.x * snake.SKALA , snake.head.y * snake.SKALA, snake.SKALA, snake.SKALA, 90, 180);
		if(snake.kierunek == 3)
			g.fillArc(snake.head.x * snake.SKALA , snake.head.y * snake.SKALA, snake.SKALA, snake.SKALA, -90, 180);
		
		g.setColor(Color.RED);
		g.fillOval(snake.wisienka.x * snake.SKALA , snake.wisienka.y * snake.SKALA , snake.SKALA, snake.SKALA);
		
		
		Font fnt3 = new Font("arial", Font.CENTER_BASELINE, snake.WIDTH/50);
		g.setFont(fnt3);
		g.setColor(Color.LIGHT_GRAY);
		String str = "Wynik: " + snake.wynik + " D�ugo��: " + snake.dlugoscSnake;
		
		g.drawString(str, (int)(snake.WIDTH/2 - str.length() * 3.5f), snake.WIDTH/60);
		
		str = "Koniec GRY!";

		if (snake.granica)
		{
			g.drawString(str, (int) (snake.WIDTH/2 - str.length() * 3.5f), snake.HEIGHT / 4);
		}
		str = "Pauza";

		if (snake.pauza && !snake.granica)
		{
			g.drawString(str, (int) (snake.WIDTH/2 - str.length() * 3.5f), snake.HEIGHT / 4);
		}
	}
		
	}

		
}

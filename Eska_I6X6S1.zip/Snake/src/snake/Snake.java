package snake;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
/**
 * Klasa implementuje gr� Snake
 * @author Wojciech Kwiatkowski
 */
@SuppressWarnings("serial")
public class Snake extends JFrame implements ActionListener, KeyListener{
	
	public static Snake snake;
	public JFrame jframe,frame;
	public Timer timer = new Timer(10, this);
	public Point head, wisienka;
	public RysujObraz rysujObraz;
	public Random random;
	public static String nick = "Player";
	public static final int GORA = 0, DOL = 1, LEWO = 2, PRAWO = 3;
	public int wynik = 0, dlugoscSnake = 0, zmiana_polozenia = 0, kierunek = PRAWO;
	public int SKALA = 13;
	public int PREDKOSC = 3;
	public static int WIDTH;
	public static int HEIGHT;
	public static boolean granica = false, pauza = false, start = false;
	public static boolean flaga[] = new boolean[100]; 
	public ArrayList<Point> polozenieSnake = new ArrayList<Point>();
	

	Object[] opcje = {"Zacznij od nowa!","Wr�� do menu", "Zako�cz gr�.", };
	Object[] opcje_pauza = { "Wzn�w gr�" ,"Zacznij od nowa!", "Wr�� do menu", "Zako�cz gr�.", };
	
	/**
	 * Mo�liwe stany gry
	 */
	public static enum STATUS{
		MENU,
		GRA;
	};
	
	public static STATUS status = STATUS.MENU;

	/**
	 * Funkcja tworzy startowe okno z menu gry i obs�uguje przyciski menu
	 */
	private void initialize() {
		jframe = new JFrame();
		jframe.setBounds(100, 100, 705, 600);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setResizable(false);
		jframe.getContentPane().setLayout(null);
		jframe.getContentPane().setBackground(new Color(0, 0, 0));
		jframe.setLocationRelativeTo(null);
		jframe.setAlwaysOnTop(true);
		JButton btnNewButton = new JButton("START");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Cambria", Font.BOLD, 47));
		
		btnNewButton.setBounds(260, 390, 200, 108);
		
		btnNewButton.setOpaque(false);
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBorder(null);
		btnNewButton.setFocusPainted(false);
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				status = STATUS.GRA;
				startSnake();
				jframe.setVisible(false);
				start();
			}
		});
		
		jframe.getContentPane().add(btnNewButton);
		
		
		
		JButton btnUstawienia = new JButton("USTAWIENIA");
		btnUstawienia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Ustawienia ustawienia = new Ustawienia();
				ustawienia.jframe.setVisible(true);
				ustawienia.jframe.setAlwaysOnTop(true);
				ustawienia.jframe.setLocationRelativeTo(null);
				
			}
		});
		btnUstawienia.setFont(new Font("Cambria", Font.PLAIN, 25));
		
		btnUstawienia.setBounds(40, 400, 150, 108);
		btnUstawienia.setForeground(Color.WHITE);
		btnUstawienia.setOpaque(false);
		btnUstawienia.setContentAreaFilled(false);
		btnUstawienia.setBorderPainted(false);
		btnUstawienia.setBorder(null);
		btnUstawienia.setFocusPainted(false);
		jframe.getContentPane().add(btnUstawienia);
		
		JButton btnNewButton_1 = new JButton("ZAMKNIJ");
		btnNewButton_1.setFont(new Font("Cambria", Font.PLAIN, 25));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timer.stop();
				jframe.dispose();
			}
		});
		
		btnNewButton_1.setBounds(500, 400, 150, 108);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setOpaque(false);
		btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setFocusPainted(false);
		jframe.getContentPane().add(btnNewButton_1);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(getClass().getResource("/imgs/backgr.jpg")));
		lblNewLabel.setBounds(50, 0, 705, 600);
		jframe.getContentPane().add(lblNewLabel);
		jframe.getRootPane().setDefaultButton(btnNewButton);
	}
	
	/**
	 *Funkcja tworzy okno gry  
	 */
	private void start(){
			frame = new JFrame("Snake");
			frame.addKeyListener(this);
			frame.setVisible(true);
			if(SKALA == 10) frame.setSize(706, 599);
			else if(SKALA == 13) frame.setSize(708, 589);
			else if(SKALA == 16) frame.setSize(709, 571);	
			frame.setResizable(false);
			frame.setLocationRelativeTo(null);
			frame.add(rysujObraz = new RysujObraz());
			frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
			
	}
	
	/**
	 * Konstruktor wywo�uje funkcj� initialize
	 */
	public Snake() {
		initialize();
		addKeyListener(this);
		
	}
	/**
	 * Funkcja ustawia wszystkie zmienne na warto�ci pocz�tkowe i staruje timer.
	 */
	public void startSnake(){
		
		System.out.println("startSnake");
		if (flaga[KeyEvent.VK_UP] || flaga[KeyEvent.VK_LEFT] || flaga[KeyEvent.VK_RIGHT] || flaga[KeyEvent.VK_DOWN]){
			System.out.println("Czyszczenie");
			for(int i = 0; i< flaga.length; ++i)
				flaga[i] = false;
		}
		granica = false;
		pauza = false;
		wynik = 0;
		dlugoscSnake = 10;
		zmiana_polozenia = 0;
		kierunek = PRAWO;
		polozenieSnake.clear();
		random = new Random();
		head = new Point(0,random.nextInt(jframe.getHeight()/SKALA - 3)); 
		wisienka = new Point(random.nextInt(jframe.getWidth()/SKALA ),random.nextInt(jframe.getHeight()/SKALA -3));
		timer.start();
		
	}
	
	/**
	 * Funkcja obs�uguje zmian� po�o�enia w�a oraz zdarzenia powoduj�ce koniec gry oraz pauz�.
	 */

	@Override
	public void actionPerformed(ActionEvent arg0) {
	
	if(status==STATUS.GRA){
		rysujObraz.repaint();
		obsluga_klawiszy();
		zmiana_polozenia++;
		//System.out.println("zmiana pol "+zmiana_polozenia );
		if(zmiana_polozenia % PREDKOSC == 0 && head != null && !granica && !pauza){
			
			polozenieSnake.add(new Point(head.x, head.y));
			
			if(kierunek == GORA ){
				if(head.y - 1 >= 0 && zderzenie(head.x, head.y - 1))
					head = new Point(head.x, head.y - 1);
				else
					if(Ustawienia.przenikanie && zderzenie(head.x, head.y -1)){
						head.y = jframe.getHeight()/SKALA - 3;
						head = new Point(head.x, head.y);
					}
					else
					granica = true;
			}
			if(kierunek == DOL )
				if(head.y + 1 < (jframe.getHeight()/(SKALA) - 3) && zderzenie(head.x, head.y + 1))
					head = new Point(head.x, head.y + 1);
				else 
					if(Ustawienia.przenikanie && zderzenie(head.x, head.y + 1)){
						head.y = 0;
						head = new Point(head.x, head.y);
					}
					else	
					granica = true;
			
			if(kierunek == LEWO ){
				if(head.x - 1 >= 0 && zderzenie(head.x - 1, head.y))
					head = new Point(head.x - 1, head.y);
				else
					if(Ustawienia.przenikanie && zderzenie(head.x - 1, head.y)){
						head.x = jframe.getWidth()/SKALA;
						head = new Point(head.x, head.y);
					}
					else
					granica = true;
			}
			if(kierunek == PRAWO  ){
				if(head.x + 1 < (jframe.getWidth()/SKALA) && zderzenie(head.x + 1, head.y))
					head = new Point(head.x + 1, head.y);
				else
					if(Ustawienia.przenikanie && zderzenie(head.x + 1, head.y)){
						head.x = 0;
						head = new Point(head.x, head.y);
					}
					else
					granica = true;
			
			}
			
			
			if(polozenieSnake.size() > dlugoscSnake)
				polozenieSnake.remove(0); 
			
			
			
			if(wisienka != null){
				if(head.equals(wisienka)){
					wynik += 10;
					dlugoscSnake++;
					wisienka = new Point(random.nextInt(jframe.getWidth()/SKALA ),random.nextInt(jframe.getHeight()/SKALA - 3));
				}
			}
		}else
			if(granica){
				int n = JOptionPane.showOptionDialog(jframe,"Tw�j wynik = " + wynik + "\n ","Koniec GRY!", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, null,opcje,opcje[0]);
				if(n == 0){
					timer.stop();
					startSnake();
				}
				if(n == 1){
					timer.stop();
					frame.dispose();
					jframe.setVisible(true);
				}
				if (n == 2){
					frame.dispose();
					timer.stop();
				}
				
			}
			if(pauza){
				int n = JOptionPane.showOptionDialog(jframe,"Aktualny wynik = " + wynik,"Pauza", JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, null,opcje_pauza,opcje_pauza[0]);
				if(n == 0){
					pauza = false;
					
				}
				if(n == 1){
					timer.stop();
					startSnake();
				}
				if (n == 2){
					timer.stop();
					
					frame.dispose();
					jframe.setVisible(true);
				}
				if(n == 3){
					frame.dispose();
					timer.stop();
				}
			}
		}
	}
	/**
	 * Funkcja sprawdza czy nie wyst�pi�o zderzenie z ogonem w�a
	 * @param x warto�� na osi X okre�laj�ca kolejne po�o�enie w�a
	 * @param y warto�� na osi Y okre�laj�ca kolejne po�o�enie w�a
	 * @return zwraca false je�li wyst�pi�o zderzenie w przeciwnym wypadku true
	 */
	public boolean zderzenie(int x, int y) {
		for(Point point : polozenieSnake){
			if (point.equals(new Point(x,y)) ){
				return false;
			}
		}
		return true;
	}


	/**
	 * Funkcja main tworzy nowy obiekt klasy Snake
	 * @param args .
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					snake = new Snake();
					snake.jframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Fuknja obs�uguje wci�ni�te klawisze na klawiaturze
	 */
	public synchronized void obsluga_klawiszy(){
		
		if(status == STATUS.GRA){
			if(flaga[KeyEvent.VK_LEFT] &&  kierunek != PRAWO && !pauza && !flaga[KeyEvent.VK_DOWN] && !flaga[KeyEvent.VK_RIGHT] && !flaga[KeyEvent.VK_UP]){
				kierunek = LEWO;
				
			}
			else if(flaga[KeyEvent.VK_RIGHT] && kierunek != LEWO && !pauza && !flaga[KeyEvent.VK_DOWN] && !flaga[KeyEvent.VK_LEFT] && !flaga[KeyEvent.VK_UP]){
				
				kierunek = PRAWO;
				
				
			}
			else if(flaga[KeyEvent.VK_UP] && kierunek != DOL && !pauza ){
				
				kierunek = GORA;
				
				
			}
			else if(flaga[KeyEvent.VK_DOWN] && kierunek != GORA && !pauza && !flaga[KeyEvent.VK_UP] && !flaga[KeyEvent.VK_LEFT] && !flaga[KeyEvent.VK_UP]){
				
				kierunek = DOL;
			
			}
			else if(flaga[KeyEvent.VK_SPACE]){
				if(granica)
					startSnake();
				else{
					pauza = true;
					flaga[KeyEvent.VK_SPACE]=false;
				}
					
			}
		
			}
	
	}


	@Override
	public synchronized void keyPressed(KeyEvent e) {
	int k= e.getKeyCode();
	flaga[k]=true;
	
	
	}



	@Override
	public synchronized void keyReleased(KeyEvent e) {
		int k= e.getKeyCode();
		
		flaga[k]=false;
		
	}



	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}

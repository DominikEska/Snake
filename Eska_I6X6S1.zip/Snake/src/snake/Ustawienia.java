package snake;

import java.awt.Color;
import java.awt.Font;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/**
 * Klasa odpowiedzialna za utworzenie okna z ustawieniami
 * @author Wojciech Kwiatkowski
 */
@SuppressWarnings("serial")
public class Ustawienia extends JPanel{
	public static Ustawienia ustawienia;
	Snake snake = Snake.snake;
	JFrame jframe;
	public static int color_weza = 2 , color_tla = 2 , slider_pol = 3, slider1_pol = 0;
	public static boolean przenikanie = false;
	
	/**
	 * Konstruktor wywo�uje fukcje initialize
	 */
	public Ustawienia(){
		initialize();
	}
	

	/**
	 * Fukcja dodaje i obs�uguje przyciski okna ustawie�
	 */
	@SuppressWarnings("deprecation")
	private void initialize() {
		System.out.println("init");
		snake.jframe.disable();
		jframe = new JFrame();
		jframe.setResizable(false);
		jframe.setType(Type.POPUP);
		jframe.setBounds(100, 100, 312, 335);
		jframe.getContentPane().setLayout(null);
	
		WindowListener exitListener = new WindowAdapter(){
			 public void windowClosing(WindowEvent e) {
				Snake.snake.jframe.enable();
				jframe.dispose(); 
			 }
		};
		
		jframe.addWindowListener(exitListener);
	
		JLabel lblKolorWa = new JLabel("Kolor w\u0119\u017Ca");
		lblKolorWa.setHorizontalAlignment(SwingConstants.RIGHT);
		lblKolorWa.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblKolorWa.setBounds(10, 104, 123, 50);
		jframe.getContentPane().add(lblKolorWa);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(185, 120, 24, 23);
		jframe.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_weza = 2;
				
			}
		});
			
		
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setBackground(Color.CYAN);
		btnNewButton_1.setForeground(Color.CYAN);
		btnNewButton_1.setBounds(151, 120, 24, 23);
		jframe.getContentPane().add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_weza = 1;
				
			}
		});
			
		
		JButton button = new JButton("");
		button.setBackground(Color.PINK);
		button.setBounds(219, 120, 24, 23);
		jframe.getContentPane().add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_weza = 3;
				
			}
		});
		
		JButton button_1 = new JButton("");
		button_1.setBackground(Color.GREEN);
		button_1.setBounds(253, 120, 24, 23);
		jframe.getContentPane().add(button_1);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_weza = 4;
				
			}
		});
		
		JButton button_2 = new JButton("");
		button_2.setBackground(Color.BLUE);
		button_2.setBounds(151, 154, 24, 23);
		jframe.getContentPane().add(button_2);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_tla = 1;
				
			}
		});
		
		JButton button_3 = new JButton("");
		button_3.setBackground(Color.BLACK);
		button_3.setBounds(185, 154, 24, 23);
		jframe.getContentPane().add(button_3);
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_tla = 2;
				
			}
		});
		
		JButton button_4 = new JButton("");
		button_4.setBackground(Color.LIGHT_GRAY);
		button_4.setBounds(219, 154, 24, 23);
		jframe.getContentPane().add(button_4);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_tla = 3;
				
			}
		});
		
		JButton button_5 = new JButton("");
		button_5.setBackground(new Color(0, 100, 0));
		button_5.setBounds(253, 154, 24, 23);
		jframe.getContentPane().add(button_5);
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				color_tla = 4;
				
			}
		});
		
		JLabel lblNewLabel_1 = new JLabel("Kolor t\u0142a");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(0, 149, 133, 29);
		jframe.getContentPane().add(lblNewLabel_1);
		
		JButton btnOk = new JButton("OK");
		btnOk.setBounds(108, 261, 89, 23);
		jframe.getContentPane().add(btnOk);
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				snake.jframe.enable();
				jframe.dispose();
				
			}
		});
		JSlider slider = new JSlider();
		slider.setSnapToTicks(true);
		slider.setMajorTickSpacing(3);
		slider.setPaintTicks(true);
		slider.setMaximum(6);
		slider.setValue(slider_pol);
		slider.setBounds(151, 85, 126, 24);
		slider.addChangeListener(new  ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				if(slider.getValue() == 0) {
					snake.PREDKOSC = 5;
					slider_pol = 0;
				}
				else if(slider.getValue() == 3){
					snake.PREDKOSC = 3;
					slider_pol = 3;
				}
				else if(slider.getValue() == 6){
					snake.PREDKOSC = 2;
					slider_pol = 6;
				}
				
			}
		});
		jframe.getContentPane().add(slider);
		
		
		JLabel lblNewLabel_2 = new JLabel("Szybko\u015B\u0107 w\u0119\u017Ca");
		lblNewLabel_2.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(20, 85, 113, 24);
		jframe.getContentPane().add(lblNewLabel_2);
		
		
		JLabel lblGgg = new JLabel("Rozmiar w\u0119\u017Ca");
		lblGgg.setHorizontalAlignment(SwingConstants.RIGHT);
		lblGgg.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblGgg.setBounds(10, 189, 123, 22);
		jframe.getContentPane().add(lblGgg);
		
		JSlider slider_1 = new JSlider();
		slider_1.setMajorTickSpacing(3);
		slider_1.setPaintTicks(true);
		slider_1.setSnapToTicks(true);
		slider_1.setValue(0);
		slider_1.setMaximum(6);
		slider_1.setValue(slider1_pol);
		slider_1.setBounds(151, 188, 126, 23);
		slider_1.addChangeListener(new  ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
			
				if(slider_1.getValue() == 0) {
					snake.SKALA = 10;
					slider1_pol = 0;
				}
				else if(slider_1.getValue() == 3){
					snake.SKALA = 13;
					slider1_pol = 3;
				}
				else if(slider_1.getValue() == 6){
					snake.SKALA = 16;
					slider1_pol = 6;
				}
				
			}
		});
		jframe.getContentPane().add(slider_1);
		
		
		JLabel lblUstawienia = new JLabel("USTAWIENIA");
		lblUstawienia.setFont(new Font("Verdana", Font.BOLD, 20));
		lblUstawienia.setBounds(91, 11, 160, 45);
		jframe.getContentPane().add(lblUstawienia);
		
		JLabel lblPrzenikanie = new JLabel("Przenikanie ");
		lblPrzenikanie.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPrzenikanie.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblPrzenikanie.setBounds(39, 222, 94, 22);
		jframe.getContentPane().add(lblPrzenikanie);
		
		JCheckBox checkBox = new JCheckBox("");
		checkBox.setBounds(151, 224, 97, 23);
		checkBox.setSelected(przenikanie);
		jframe.getContentPane().add(checkBox);
		checkBox.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					przenikanie = true;
				}
				if(e.getStateChange() == ItemEvent.DESELECTED){
					przenikanie = false;
				}
			}
			
		});
		
	}
}

